# Slam-With-V-Rep|Without Using Ros
![](picture/gridmap.PNG)


 Simultaneous localization and mapping (SLAM) in v rep with e-puck robot using custermised Api (Copy simExtGridMap_binaries.zip/window/simExtGridMap.dll to CoppeliaSim folder).
  Read thread script of scene to understand working and follow below link to understand more
 
 link:https://www.youtube.com/watch?v=fV0ZoDa1FaQ&list=PLjzuoBhdtaXOoqkJUqhYQletLLnJP8vjZ&index=59&t=0s
 
 Contact:
 
 email id: vermahrithik10@gmail.com 
 
 Direct message me at instagram:https://www.instagram.com/hrithik.verma.100/?hl=en
 
